// automaster runner: built from extension/src by scripts/build-extension.mjs. don't edit by hand.
"use strict";
(() => {
  // src/lib/labels.ts
  function cleanLabel(label, options = []) {
    let l = label.replace(/\s+/g, " ").replace(/\(?(required|optional)\)?/gi, "").trim();
    const tails = [...options, "select", "select one", "choose", "choose one", "please select", "-- select --"].map((o) => o.trim().toLowerCase()).filter(Boolean).sort((a, b) => b.length - a.length);
    for (let guard = 0; guard < 60; guard++) {
      const low = l.toLowerCase();
      const t = tails.find((o) => low.endsWith(` ${o}`) && low.length > o.length + 3);
      if (!t) break;
      l = l.slice(0, l.length - t.length).trim();
    }
    return l.replace(/\s*[*:]+\s*$/, "").trim();
  }

  // src/lib/never-fill.ts
  var NEVER_FILL = /passport|national\s*id|\bnin\b|\bssn\b|social\s*security|tax\s*id|\bbvn\b|password|passcode|\bpin\b|security\s*(question|answer)|card\s*(number|holder)|\bcvv\b|\bcvc\b|expir|iban|account\s*number|routing|signature/i;

  // src/lib/cloud-engine.ts
  function ask(state, f, key) {
    const label = cleanLabel(f.label, f.options).slice(0, 200);
    if (!label) return;
    const list = state.questions ?? [];
    const i = list.findIndex((q2) => q2.label.toLowerCase() === label.toLowerCase());
    const q = { label, type: f.type, ...f.options?.length ? { options: f.options.filter((o) => o && !/^(select|choose|please|--)/i.test(o.trim())).slice(0, 40) } : {}, ...key ? { key } : {} };
    if (i >= 0) list[i] = { ...list[i], ...q, key: key ?? list[i].key };
    else list.push(q);
    state.questions = list.slice(-12);
  }
  function questionNote(state) {
    const qs = state.questions ?? [];
    if (!qs.length) return missingNote(state.missing ?? []);
    return `the portal asks ${qs.length === 1 ? "something" : `${qs.length} things`} your profile doesn't answer yet: ${qs.slice(0, 3).map((q) => q.label.slice(0, 60)).join("; ")}. Your interviewer will ask you, and the agents carry on once you answer`;
  }
  var FINAL = /^(submit( (my|the|your))?( application)?|submit (and|&) pay|sign (and|&) submit|submit now|final submit)$/i;
  var NEXT = /^(save (and|&) (continue|next)|next( page| section| step)?|continue( to .{0,30})?|proceed|save (and|&) proceed|go to next|save and go to next|suivant|continuer)\b/i;
  var START = /^(start|begin|continue|resume) (my |an |your |a new |new )?application\b.{0,20}$|^apply( now| online| today| here)?( for (this|the) program.{0,30})?$|^start( here| now)?$|^(how to )?apply to (this|the) program$/i;
  var CREATE = /^((create|register|sign up)( for| an| a| new| my| your)*( account| profile| login| here| e-?id| user ?id| username| applicant account)?|new (user|applicant)s?|first.?time (user|applicant)s?.*|create (a )?login|(get|request) (an? )?(e-?id|account))[?!.]*$/i;
  var SIGNIN = /^(sign in|log ?in|login|continue|next|submit)$/i;
  var CREATE_SUBMIT = /^(create( (an |my )?account)?|register|sign up|continue|submit|next|(set|save|create|update|change|choose) (my |your |a )?password|save|activate( (my )?account)?|finish|complete( registration)?|confirm)$/i;
  var VERIFY_BTN = /^(verify|confirm|submit|continue|next|activate|log ?in|login|sign in)$/i;
  var SIGNUP_WORDS = /(create (an |your )?account|register|sign up|new user|confirm password|re-?enter password)/i;
  var CHECK_EMAIL = /(check your (e-?mail|inbox)|verify your e-?mail|we('ve| have) sent (you )?(an? )?(e-?mail|code|link)|activation (link|e-?mail)|confirm your e-?mail)/i;
  var CODE_LABEL = /(verification|security|confirmation|access|one.?time|activation)?\s*(code|pin|otp|passcode)\b/i;
  var REGISTER_PAGE = /(regist|create.?(an.?)?account|sign.?up|new.?user)/i;
  var LOGIN_LINK = /^(log ?in|login|sign ?in)( here| now)?$|^returning (users?|applicants?)/i;
  var SIGN_WORDS = /\b(log ?-?in|login|log ?on|logon|sign ?-?in)\b|^(returning|existing) (users?|applicants?|accounts?)\b|already (have|registered|created)( an)? account|access (my|your) (application|account|portal)/i;
  var NOT_MINE = /\b(sign ?-?up|register|create|new (user|applicant)|log ?out|sign ?out|faculty|staff|employees?|recommend(er|ers|ation)|referees?|reviewers?|admin(istrator)?|current students?|alumni|partners?|agents?|counsell?ors?|google|facebook|linkedin|apple|microsoft|github|forgot|reset|help|trouble)\b/i;
  function isSignIn(label) {
    const l = label.replace(/\s+/g, " ").trim();
    return l.length > 0 && l.length <= 48 && SIGN_WORDS.test(l) && !NOT_MINE.test(l);
  }
  var findBy = (s, ok) => s.buttons.find((b) => ok(clean(b.label)) && goesSomewhere(s, b));
  var BLOCK_TITLE = /^(access denied|forbidden|403\b|request (blocked|rejected)|attention required|just a moment|pardon our interruption|are you a (robot|human)|you have been blocked|blocked)/i;
  var BLOCK_BODY = /(unusual traffic from your|automated (requests|queries|access)|request (was|has been) (blocked|rejected)|verify (that )?you are (a )?human|checking (if the site connection is secure|your browser before)|enable javascript and cookies to continue)/i;
  var isBlockPage = (s) => BLOCK_TITLE.test(s.title.trim()) || BLOCK_BODY.test(s.body.slice(0, 800));
  var TERMS = /(i (have read and )?(agree|accept)|terms (of use|and conditions|of service)|privacy (policy|notice))/i;
  function classify(s) {
    if (s.confirmation) return "confirmation";
    if (s.captcha) return "captcha";
    if (s.payment) return "payment";
    const pw = s.allFields.filter((f) => f.type === "password");
    const code = s.allFields.find((f) => f.type !== "password" && CODE_LABEL.test(f.label) && !/zip|postal|area|country/i.test(f.label));
    if (pw.length >= 2 || pw.length === 1 && SIGNUP_WORDS.test(s.body.slice(0, 3e3)) && s.allFields.length >= 4) return "signup";
    if (pw.length === 1) return "login";
    if (code && s.allFields.length <= 3) return "verify_code";
    if (CHECK_EMAIL.test(s.body) && s.fields.length <= 1) return "check_email";
    return "form";
  }
  var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  var active = /* @__PURE__ */ new WeakMap();
  var frameOf = (page) => active.get(page) ?? page.mainFrame();
  async function snapFrame(f) {
    try {
      await f.helper();
      return await f.evaluate(() => window.__am.snapshot(), void 0);
    } catch {
      return null;
    }
  }
  async function snapMain(page) {
    for (let i = 0; i < 3; i++) {
      const s = await snapFrame(page.mainFrame());
      if (s) return s;
      await page.waitForLoadState("domcontentloaded", { timeout: 1e4 }).catch(() => {
      });
      await sleep(800);
    }
    const url = await page.url();
    return { url, title: "", body: "", captcha: false, payment: false, confirmation: false, fingerprint: `blank:${url}`, fields: [], allFields: [], buttons: [] };
  }
  async function snap(page) {
    const main = await snapMain(page);
    let best = { f: page.mainFrame(), s: main };
    const score = (x) => x.allFields.length * 3 + x.buttons.length;
    let confirmation = main.confirmation;
    let captcha = main.captcha;
    for (const f of await page.frames()) {
      if (f.isMain || !f.url().startsWith("http")) continue;
      const s = await snapFrame(f);
      if (!s) continue;
      confirmation ||= s.confirmation;
      captcha ||= s.captcha;
      if ((s.allFields.length || s.buttons.length > main.buttons.length) && score(s) > score(best.s)) best = { f, s };
    }
    active.set(page, best.f);
    return { ...best.s, captcha, confirmation, title: main.title || best.s.title };
  }
  async function click(page, id) {
    const sel = `[data-am-id="${id}"]`;
    const href = await frameOf(page).evaluate((q) => {
      const a = document.querySelector(q);
      return a && a.tagName === "A" && a.target && a.target !== "_self" && /^https?:/.test(a.href) ? a.href : null;
    }, sel).catch(() => null);
    if (href) {
      await page.goto(href, { timeout: 45e3 });
      await page.waitForLoadState("networkidle", { timeout: 15e3 }).catch(() => {
      });
      await sleep(1200);
      return;
    }
    try {
      await Promise.all([page.waitForLoadState("domcontentloaded").catch(() => {
      }), frameOf(page).click(sel, { timeout: 8e3 })]);
    } catch {
      await frameOf(page).evaluate((s) => document.querySelector(s)?.click(), sel);
    }
    await page.waitForLoadState("networkidle", { timeout: 15e3 }).catch(() => {
    });
    await sleep(1200);
  }
  async function fillText(page, id, value) {
    await frameOf(page).fill(`[data-am-id="${id}"]`, value, { timeout: 1e4 });
  }
  var clean = (l) => l.replace(/[\u2190-\u21ff\u2794-\u27bf›»<>←→]+/g, " ").split(/\s+\/\s+|\s+\|\s+/)[0].replace(/\s+/g, " ").trim();
  var here = (u) => u.replace(/#.*$/, "").replace(/\/$/, "");
  var goesSomewhere = (s, b) => !b.href || /^javascript:/i.test(b.href) ? true : here(b.href) !== here(s.url);
  var find = (s, re, linksOnly = false) => s.buttons.find((b) => re.test(clean(b.label)) && (!linksOnly || b.link) && goesSomewhere(s, b));
  async function runEngine(page, deps2, state, budgetMs) {
    const end = Date.now() + budgetMs;
    let filled = 0;
    while (Date.now() < end) {
      if (deps2.shouldStop?.()) return { outcome: { kind: "continue", note: "paused" }, state, filled };
      state.steps += 1;
      state.totalSteps = (state.totalSteps ?? 0) + 1;
      if (state.steps > 60) return { outcome: { kind: "continue", note: "continuing on the next pages" }, state, filled };
      if (state.totalSteps > 600) return { outcome: { kind: "needs_you", reason: "stuck", note: "the agents have been through this portal hundreds of pages without finishing; please check where it stands" }, state, filled };
      await page.waitForLoadState("domcontentloaded").catch(() => {
      });
      await sleep(800);
      let s = await snap(page);
      if (isBlockPage(s)) {
        await sleep(8e3);
        s = await snap(page);
        if (isBlockPage(s)) return { outcome: { kind: "needs_you", reason: "blocked", note: "this portal blocks the browser the agents are using" }, state, filled };
      }
      state.samePageCount = s.fingerprint === state.lastFingerprint ? (state.samePageCount ?? 0) + 1 : 0;
      state.lastFingerprint = s.fingerprint;
      if (REGISTER_PAGE.test(s.url) && /^(forbidden|access denied|403|request blocked)/i.test(s.title.trim() || s.body.trim().slice(0, 40))) {
        return { outcome: { kind: "needs_you", reason: "account", note: "this portal won't let an automated browser create the account" }, state, filled };
      }
      if (state.samePageCount >= 2 && REGISTER_PAGE.test(`${s.url} ${s.title}`) && !(state.missing ?? []).length && !/(invalid|do(es)? not exist|already (exists|registered|in use)|not (be )?found|error)/i.test(s.body)) {
        return { outcome: { kind: "needs_you", reason: "account", note: "this portal won't let an automated browser create the account" }, state, filled };
      }
      if (state.samePageCount >= 3) {
        const req = s.fields.map((f) => f.label.slice(0, 50));
        const stillEmpty = s.fields.filter((x) => x.required && !NEVER_FILL.test(`${x.label} ${x.name ?? ""}`));
        for (const f of stillEmpty) ask(state, f);
        const fix = (state.missing ?? []).length || stillEmpty.length ? questionNote(state) : "";
        const err = (s.errors ?? []).join("; ").slice(0, 160);
        const stop = { kind: "needs_you", reason: fix ? "question" : "stuck", note: fix || (err ? `the portal says: ${err}` : req.length ? `the portal wants: ${req.slice(0, 3).join("; ")}` : "the portal didn't accept this page") };
        if (fix || state.samePageCount >= 6) return { outcome: stop, state, filled };
        const o2 = await navStep(page, deps2, s, state, `the same page came back ${state.samePageCount} times after the usual steps${err ? `; the portal shows: ${err}` : ""}`, stop);
        if (o2) return { outcome: o2, state, filled };
        continue;
      }
      const kind = classify(s);
      if (kind === "confirmation") {
        if (state.submitClicked || state.reachedSubmit) return { outcome: { kind: "submitted", note: "portal showed a confirmation" }, state, filled };
      }
      if (kind === "captcha") return { outcome: { kind: "needs_you", reason: "captcha", note: "the portal is showing a bot check. open the live view and complete it; the runner continues on its own" }, state, filled };
      if (kind === "payment") {
        state.reachedSubmit = true;
        return { outcome: { kind: "needs_you", reason: "payment", note: "payment page: open the live view and pay the fee; the runner confirms the submission after" }, state, filled };
      }
      if (kind === "login") {
        let login = await deps2.existingLogin();
        if (!login && deps2.loginFromMail) login = await deps2.loginFromMail(Date.now() - 60 * 864e5);
        if (!login) {
          const create = find(s, CREATE);
          if (create) {
            await deps2.progress("creating your portal account");
            state.accountAt = Date.now();
            await click(page, create.id);
            continue;
          }
          return { outcome: { kind: "needs_you", reason: "login", note: "this portal only has a sign-in page, with no way to create an account here. Create your account where the school says, then add it under Portal logins; the agents sign in with it and carry on" }, state, filled };
        }
        const pw = s.allFields.find((f) => f.type === "password");
        const user = s.allFields.find((f) => f.type !== "password" && f.type !== "checkbox" && /(e-?mail|user|login|account)/i.test(`${f.label} ${f.autocomplete ?? ""}`)) ?? s.allFields.find((f) => f.type === "email" || f.type === "text");
        const isIdBox = /user\s*(id|name)|login\s*(id|name)|identifiant|oprid/i.test(`${user?.label ?? ""} ${user?.name ?? ""}`) && !/e-?mail/i.test(user?.label ?? "");
        if (user) await fillText(page, user.id, !login.login_email.includes("@") || !isIdBox ? login.login_email : login.login_email.split("@")[0].replace(/[^a-z0-9._-]/gi, "").slice(0, 30));
        await fillText(page, pw.id, login.password);
        const go = find(s, SIGNIN) ?? findBy(s, isSignIn);
        await deps2.progress("signing in to the portal");
        if (go) await click(page, go.id);
        else await frameOf(page).press(`[data-am-id="${pw.id}"]`, "Enter").catch(() => {
        });
        const after = await snap(page);
        if (classify(after) === "login" && /(invalid|incorrect|wrong|not recogni[sz]ed|failed|does not exist|no account)/i.test(after.body)) {
          if (!state.triedMailLogin && deps2.loginFromMail) {
            state.triedMailLogin = true;
            const issued = await deps2.loginFromMail(Date.now() - 60 * 864e5);
            if (issued && (issued.password !== login.password || issued.login_email !== login.login_email)) {
              await deps2.progress("found the login the portal emailed you; signing in");
              continue;
            }
          }
          if (!state.signedIn) return { outcome: { kind: "needs_you", reason: "account", note: "waiting for you to create the portal account" }, state, filled };
          return { outcome: { kind: "needs_you", reason: "login", note: "the portal rejected the saved password. Check it under Portal logins (or reset it on the portal and save the new one there); the agents sign in again by themselves" }, state, filled };
        }
        if (classify(after) !== "login") state.signedIn = true;
        continue;
      }
      if (kind === "signup") {
        const login = await deps2.existingLogin() ?? await deps2.createLogin(deps2.accountEmail);
        await deps2.progress("creating your portal account");
        const pws = s.allFields.filter((f) => f.type === "password");
        for (const p of pws) await fillText(page, p.id, login.password);
        const others = s.fields.filter((f) => f.type !== "password");
        for (const f of others.filter((f2) => f2.type === "email" || /e-?mail/i.test(f2.label))) await fillText(page, f.id, login.login_email);
        const rest = others.filter((f) => !(f.type === "email" || /e-?mail/i.test(f.label)));
        filled += await applyFills(page, deps2, rest, state);
        await acceptTerms(page, s);
        const go = find(s, CREATE_SUBMIT);
        if (!go) return { outcome: { kind: "needs_you", reason: "stuck", note: "filled the sign-up form but couldn't find the create button" }, state, filled };
        state.accountAt = Date.now();
        await click(page, go.id);
        continue;
      }
      if (kind === "verify_code" || kind === "check_email") {
        const since = state.accountAt ?? state.verifyWaitSince ?? Date.now() - 30 * 6e4;
        state.verifyWaitSince ??= Date.now();
        if (!deps2.canReadMail) {
          return { outcome: { kind: "needs_you", reason: "verification", note: `the portal sent a verification ${kind === "verify_code" ? "code" : "link"} to your email. open the live view and enter it (connect gmail so the agents can do this for you)` }, state, filled };
        }
        const v = await deps2.verification(since);
        if (!v || !v.code && !v.link) {
          if (Date.now() - state.verifyWaitSince > 20 * 6e4) return { outcome: { kind: "needs_you", reason: "verification", note: "the portal's verification email hasn't arrived after 20 minutes" }, state, filled };
          return { outcome: { kind: "wait", note: "waiting for the portal's verification email", seconds: 60 }, state, filled };
        }
        state.verifyWaitSince = void 0;
        if (kind === "verify_code" && v.code) {
          const box = s.allFields.find((f) => CODE_LABEL.test(f.label));
          await fillText(page, box.id, v.code);
          const go = find(s, VERIFY_BTN);
          if (go) await click(page, go.id);
          else await page.pressEnter();
          continue;
        }
        if (v.link) {
          await deps2.progress("confirming your email with the portal");
          await page.goto(v.link);
          continue;
        }
        return { outcome: { kind: "needs_you", reason: "verification", note: "found the verification email but couldn't use it; open the live view" }, state, filled };
      }
      if (s.fields.length) {
        await deps2.progress(`filling ${s.fields.length} field${s.fields.length > 1 ? "s" : ""}`);
        filled += await applyFills(page, deps2, s.fields, state);
        await acceptTerms(page, s);
        await sleep(1500);
        const tried = new Set(s.fields.map((f) => f.id));
        const fresh = (await snap(page)).fields.filter((f) => !tried.has(f.id) || (f.options?.length ?? 0) > (s.fields.find((x) => x.id === f.id)?.options?.length ?? 0));
        if (fresh.length) filled += await applyFills(page, deps2, fresh, state);
      }
      const now = await snap(page);
      const empty = now.fields.filter((f) => f.required).map((f) => f.label.slice(0, 50));
      if (empty.length) {
        for (const f of now.fields.filter((x) => x.required)) ask(state, f);
        return { outcome: { kind: "needs_you", reason: "question", note: questionNote(state).slice(0, 290) }, state, filled };
      }
      const submit = find(now, FINAL);
      if (submit) {
        state.reachedSubmit = true;
        const d = await deps2.canSubmit();
        if (!d.allowed) return { outcome: { kind: "needs_you", reason: "stuck", note: `ready to submit: ${d.reason}` }, state, filled };
        await deps2.progress("submitting your signed packet");
        state.submitClicked = true;
        await click(page, submit.id);
        continue;
      }
      const haveLogin = !s.fields.length && !!await deps2.existingLogin();
      const next = find(now, NEXT) ?? (!s.fields.length && haveLogin ? find(now, LOGIN_LINK) ?? findBy(now, isSignIn) : void 0) ?? find(now, START) ?? find(now, CREATE) ?? (s.fields.length ? find(now, CREATE_SUBMIT) : void 0);
      if (next) {
        await click(page, next.id);
        continue;
      }
      if (kind === "confirmation") return { outcome: { kind: "needs_you", reason: "stuck", note: "the portal says the application is complete, but the runner didn't submit it. check it" }, state, filled };
      const o = await navStep(page, deps2, now, state, "none of the usual buttons (next, continue, start, sign in, create account) are on this page", { kind: "needs_you", reason: "stuck", note: "can't find the next step on this page; open the portal and move to the next section" });
      if (o) return { outcome: o, state, filled };
    }
    return { outcome: { kind: "continue", note: "continuing" }, state, filled };
  }
  var DETAIL = {
    date_of_birth: "date of birth",
    dob_month: "date of birth",
    dob_day: "date of birth",
    dob_year: "date of birth",
    phone: "phone",
    address_line1: "address",
    address_line2: "address",
    city: "city",
    state: "state/province",
    postal_code: "postal code",
    country: "country",
    gender: "gender",
    citizenship: "citizenship"
  };
  function missingNote(keys) {
    const labels = [...new Set(keys.map((k) => DETAIL[k] ?? (k.startsWith("rec") ? "recommenders" : k.startsWith("edu") ? "education history" : k.startsWith("work") ? "work history" : k.replace(/_/g, " "))))];
    return labels.length ? `add your ${labels.slice(0, 4).join(", ")} in Profile, under Details for application forms, then choose Try again` : "";
  }
  var NAV_BUDGET = 12;
  var DANGEROUS = /\b(pay|payment|checkout|delete|remove|withdraw|cancel (my |the )?application|deactivate|unsubscribe|sign out|log ?out)\b/i;
  async function navStep(page, deps2, s, state, why, fallback) {
    if (!deps2.navigate || (state.navCalls ?? 0) >= NAV_BUDGET) return fallback;
    state.navCalls = (state.navCalls ?? 0) + 1;
    const history = state.navHistory ?? [];
    const a = await deps2.navigate({ why, snapshot: s, history: history.slice(-8), signedIn: !!state.signedIn, haveLogin: !!await deps2.existingLogin() }).catch(() => null);
    if (!a) return fallback;
    const log = (t) => state.navHistory = [...history, t].slice(-12);
    const root = (u) => {
      try {
        return new URL(u).hostname.split(".").slice(-2).join(".");
      } catch {
        return "";
      }
    };
    if (a.action === "handoff") {
      log(`handoff: ${a.note}`);
      return { kind: "needs_you", reason: "stuck", note: a.note.slice(0, 280) || fallback.note };
    }
    if (a.action === "wait_email") {
      log("wait for email");
      return { kind: "wait", note: a.note || "waiting for an email from the portal", seconds: 90 };
    }
    if (a.action === "done") {
      log("done?");
      if (s.confirmation && (state.reachedSubmit || state.submitClicked)) return { kind: "submitted", note: "portal showed a confirmation" };
      return { kind: "needs_you", reason: "stuck", note: `the agents think this application may be finished; please check the portal. ${a.note}`.slice(0, 280) };
    }
    if (a.action === "goto") {
      const onPage = s.buttons.some((b2) => b2.href === a.url);
      if (!/^https:\/\//.test(a.url) || !onPage && root(a.url) !== root(s.url)) {
        log(`refused goto ${a.url}`);
        return null;
      }
      log(`goto ${a.url}`);
      await page.goto(a.url, { timeout: 45e3 });
      await sleep(1200);
      return null;
    }
    if (a.action === "fill") {
      const f = s.fields.find((x) => x.id === a.target_id);
      const fill = f && deps2.fillFromKey ? await deps2.fillFromKey(f, a.sheet_key) : null;
      if (!f || !fill || NEVER_FILL.test(`${f.label} ${f.name ?? ""}`)) {
        log(`couldn't fill ${f?.label ?? a.target_id} from ${a.sheet_key}`);
        return null;
      }
      log(`fill "${f.label.slice(0, 40)}" from ${a.sheet_key}`);
      if (fill.action === "upload") {
        const file = await deps2.file(fill.file);
        await frameOf(page).setInputFiles(`[data-am-id="${f.id}"]`, file);
      } else await frameOf(page).evaluate((x) => window.__am.apply(x), fill);
      return null;
    }
    const b = s.buttons.find((x) => x.id === a.target_id);
    if (!b) {
      log(`no such button ${a.target_id}`);
      return null;
    }
    const label = clean(b.label);
    if (DANGEROUS.test(label)) {
      log(`refused "${label}"`);
      return { kind: "needs_you", reason: /pay|checkout/i.test(label) ? "payment" : "stuck", note: /pay|checkout/i.test(label) ? "payment step: pay the application fee yourself; the agents confirm the submission after" : `the next step is "${label}", which the agents never press for you` };
    }
    if (FINAL.test(label) || /^submit\b/i.test(label)) {
      state.reachedSubmit = true;
      const d = await deps2.canSubmit();
      if (!d.allowed) return { kind: "needs_you", reason: "stuck", note: `ready to submit: ${d.reason}` };
      state.submitClicked = true;
    }
    log(`click "${label}"`);
    await deps2.progress(a.note ? a.note.slice(0, 80) : `pressing "${label}"`);
    await click(page, b.id);
    return null;
  }
  async function applyFills(page, deps2, fields, state) {
    const safe = fields.filter((f) => !NEVER_FILL.test(`${f.label} ${f.name ?? ""}`));
    if (!safe.length) return 0;
    const fills = await deps2.map(safe);
    let n = 0;
    for (const f of fills) {
      try {
        if (f.action === "skip") {
          const field = safe.find((x) => x.id === f.id);
          if (state && f.reason.startsWith("missing:") && field?.required) {
            state.missing = [.../* @__PURE__ */ new Set([...state.missing ?? [], f.reason.slice(8)])];
            ask(state, field, f.reason.slice(8));
          }
          continue;
        }
        if (f.action === "upload") {
          const file = await deps2.file(f.file);
          await frameOf(page).setInputFiles(`[data-am-id="${f.id}"]`, file);
          n++;
          continue;
        }
        const ok = await frameOf(page).evaluate((x) => window.__am.apply(x), f);
        if (ok) n++;
      } catch {
      }
    }
    return n;
  }
  async function acceptTerms(page, s) {
    for (const f of s.fields.filter((x) => x.type === "checkbox" && TERMS.test(x.label))) {
      await frameOf(page).evaluate((id) => window.__am.apply({ id, action: "check" }), f.id).catch(() => {
      });
    }
  }

  // extension/src/chrome-page.ts
  var sleep2 = (ms) => new Promise((r) => setTimeout(r, ms));
  function b64(buf) {
    let s = "";
    for (let i = 0; i < buf.length; i += 32768) s += String.fromCharCode.apply(null, Array.from(buf.subarray(i, i + 32768)));
    return btoa(s);
  }
  async function run(tabId, frameId, func, arg) {
    const res = await chrome.scripting.executeScript({ target: { tabId, frameIds: [frameId] }, func, args: arg === void 0 ? [] : [arg] });
    const r = res?.[0];
    if (r?.error) throw new Error(String(r.error?.message ?? r.error));
    return r?.result;
  }
  function pageClick(sel) {
    const el = document.querySelector(sel);
    if (!el) throw new Error("element gone: " + sel);
    el.scrollIntoView({ block: "center", inline: "center" });
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, button: 0 };
    el.dispatchEvent(new PointerEvent("pointerdown", o));
    el.dispatchEvent(new MouseEvent("mousedown", o));
    el.dispatchEvent(new PointerEvent("pointerup", o));
    el.dispatchEvent(new MouseEvent("mouseup", o));
    el.click();
    return true;
  }
  function pageFill(a) {
    const el = document.querySelector(a.sel);
    if (!el) throw new Error("field gone: " + a.sel);
    el.focus();
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
    if (setter) setter.call(el, a.value);
    else el.value = a.value;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.dispatchEvent(new FocusEvent("blur", { bubbles: true }));
    return true;
  }
  function pageEnter(sel) {
    const el = sel ? document.querySelector(sel) : document.activeElement;
    if (!el) return false;
    el.focus();
    const o = { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true };
    const down = el.dispatchEvent(new KeyboardEvent("keydown", o));
    el.dispatchEvent(new KeyboardEvent("keypress", o));
    el.dispatchEvent(new KeyboardEvent("keyup", o));
    const form = el.form;
    if (down && form) {
      if (typeof form.requestSubmit === "function") form.requestSubmit();
      else form.submit();
    }
    return true;
  }
  function pageFiles(a) {
    const el = document.querySelector(a.sel);
    if (!el) throw new Error("upload box gone");
    const bin = atob(a.b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    const dt = new DataTransfer();
    dt.items.add(new File([bytes], a.name, { type: a.mime }));
    el.files = dt.files;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }
  function chromePage(tabId) {
    let mainUrl = "";
    const frame = (frameId, url) => ({
      isMain: frameId === 0,
      url: () => frameId === 0 ? mainUrl || url : url,
      helper: async () => {
        await chrome.scripting.executeScript({ target: { tabId, frameIds: [frameId] }, files: ["dom-helper.js"] });
      },
      evaluate: (fn, arg) => run(tabId, frameId, fn, arg),
      click: async (sel) => {
        await run(tabId, frameId, pageClick, sel);
      },
      fill: async (sel, value) => {
        await run(tabId, frameId, pageFill, { sel, value });
      },
      press: async (sel) => {
        await run(tabId, frameId, pageEnter, sel);
      },
      setInputFiles: async (sel, file) => {
        await run(tabId, frameId, pageFiles, { sel, b64: b64(file.buffer), name: file.name, mime: file.mime });
      }
    });
    const waitLoad = async (timeout, settle) => {
      const end = Date.now() + timeout;
      await sleep2(250);
      while (Date.now() < end) {
        const t = await chrome.tabs.get(tabId);
        mainUrl = t.url || mainUrl;
        if (t.status === "complete") break;
        await sleep2(300);
      }
      if (settle) await sleep2(settle);
    };
    return {
      url: async () => {
        const t = await chrome.tabs.get(tabId);
        mainUrl = t.url || mainUrl;
        return mainUrl;
      },
      mainFrame: () => frame(0, mainUrl),
      frames: async () => {
        const all = await chrome.webNavigation.getAllFrames({ tabId }) ?? [];
        const main = all.find((f) => f.frameId === 0);
        if (main) mainUrl = main.url;
        return all.filter((f) => !f.errorOccurred).map((f) => frame(f.frameId, f.url));
      },
      goto: async (url, o) => {
        await chrome.tabs.update(tabId, { url });
        await waitLoad(o?.timeout ?? 45e3, 600);
      },
      waitForLoadState: (state, o) => waitLoad(o?.timeout ?? 15e3, state === "networkidle" ? 700 : 0),
      pressEnter: async () => {
        await run(tabId, 0, pageEnter, null);
      }
    };
  }

  // extension/src/background.ts
  var DEFAULT_API = "https://automaster-3p9i.vercel.app";
  var RUN_MS = 4 * 6e4;
  var VERSION = "0.3.1";
  var sleep3 = (ms) => new Promise((r) => setTimeout(r, ms));
  async function nap(ms) {
    const end = Date.now() + ms;
    while (Date.now() < end) {
      await sleep3(Math.min(15e3, end - Date.now()));
      await chrome.runtime.getPlatformInfo();
    }
  }
  async function cfg() {
    return chrome.storage.local.get({ api: DEFAULT_API, token: "", auto: true });
  }
  async function api(path, opts = {}) {
    const c = await cfg();
    if (!c.token) throw new Error("not connected: open automaster and choose Connect Chrome");
    const res = await fetch(c.api.replace(/\/$/, "") + path, {
      ...opts,
      headers: { authorization: `Bearer ${c.token}`, ...opts.body ? { "content-type": "application/json" } : {}, ...opts.headers || {} }
    });
    if (res.status === 401) throw new Error("this browser was disconnected: connect it again from automaster");
    return res;
  }
  async function apiJson(path, opts) {
    const res = await api(path, opts);
    const json = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(json.error || `error ${res.status}`);
    return json;
  }
  var eng = (application, op, body = {}) => apiJson("/api/runner/engine", { method: "POST", body: JSON.stringify({ application, op, ...body }) });
  async function getActive() {
    return (await chrome.storage.session.get({ active: null })).active;
  }
  async function setActive(a) {
    await chrome.storage.session.set({ active: a });
  }
  var running = false;
  var lastTasks = null;
  async function tasks() {
    lastTasks = await apiJson("/api/runner/tasks");
    const n = lastTasks.tasks.filter((t) => t.runner_status === "needs_you" && t.mode === "extension").length;
    await chrome.action.setBadgeText({ text: running ? "\u2022" : n ? String(n) : "" });
    await chrome.action.setBadgeBackgroundColor({ color: running ? "#4f46e5" : "#ea580c" });
    return lastTasks;
  }
  function notify(title, message) {
    chrome.notifications.create({ type: "basic", iconUrl: "icon.png", title, message, priority: 2 });
  }
  async function focusTab(tabId) {
    const t = await chrome.tabs.update(tabId, { active: true }).catch(() => null);
    if (t) await chrome.windows.update(t.windowId, { focused: true }).catch(() => {
    });
  }
  async function tabAlive(tabId) {
    return !!await chrome.tabs.get(tabId).catch(() => null);
  }
  var sheets = /* @__PURE__ */ new Map();
  function deps(taskId, start, tabId) {
    const host = async () => new URL((await chrome.tabs.get(tabId)).url).hostname;
    let lastNote = "";
    let stop = false;
    let checkedAt = 0;
    return {
      shouldStop: () => {
        if (Date.now() - checkedAt > 6e3) {
          checkedAt = Date.now();
          apiJson("/api/runner/tasks").then((d) => {
            const t = d.tasks.find((x) => x.id === taskId);
            stop = !t || t.mode !== "extension";
          }).catch(() => {
          });
        }
        return stop;
      },
      map: async (fields) => (await apiJson("/api/runner/map", { method: "POST", body: JSON.stringify({ application: taskId, fields: fields.slice(0, 150).map((f) => ({ id: f.id, label: f.label.slice(0, 400), type: f.type, name: f.name?.slice(0, 200), options: f.options?.slice(0, 300).map((o) => o.slice(0, 200)), required: f.required })) }) })).fills,
      file: async (key) => {
        if (!sheets.has(taskId)) sheets.set(taskId, await apiJson(`/api/runner/sheet?application=${taskId}`));
        const f = sheets.get(taskId).files.find((x) => x.key === key);
        if (!f) throw new Error("file not in the packet");
        const res = await api(f.url);
        if (!res.ok) throw new Error("couldn't fetch " + f.label);
        return { name: f.filename, mime: res.headers.get("content-type") || "application/octet-stream", buffer: new Uint8Array(await res.arrayBuffer()) };
      },
      canSubmit: () => apiJson("/api/runner/check", { method: "POST", body: JSON.stringify({ application: taskId }) }),
      existingLogin: async () => (await eng(taskId, "login_get", { host: await host() })).login,
      createLogin: async (email) => (await eng(taskId, "login_create", { host: await host(), email })).login,
      accountEmail: start.accountEmail,
      canReadMail: start.canReadMail,
      verification: async (since) => (await eng(taskId, "verification", { host: await host(), since })).found,
      navigate: async (input) => (await eng(taskId, "navigate", { host: await host(), input: { ...input, snapshot: { ...input.snapshot, body: input.snapshot.body.slice(0, 4e3) } } })).action,
      fillFromKey: async (field, key) => (await eng(taskId, "fill_key", { field: { id: field.id, label: field.label.slice(0, 400), type: field.type, name: field.name, options: field.options?.slice(0, 300), required: field.required }, key })).fill,
      loginFromMail: start.canReadMail ? async (since) => (await eng(taskId, "login_mail", { host: await host(), since })).login : void 0,
      progress: async (note) => {
        if (note === lastNote) return;
        lastNote = note;
        await eng(taskId, "progress", { note: note.slice(0, 300) }).catch(() => {
        });
      }
    };
  }
  async function peek(tabId) {
    try {
      await chrome.scripting.executeScript({ target: { tabId, frameIds: [0] }, files: ["dom-helper.js"] });
      const [r] = await chrome.scripting.executeScript({ target: { tabId, frameIds: [0] }, func: () => window.__am.snapshot() });
      return r?.result ?? null;
    } catch {
      return null;
    }
  }
  async function watch(tabId, minutes, done) {
    const end = Date.now() + minutes * 6e4;
    while (Date.now() < end) {
      await nap(4e3);
      if (!await tabAlive(tabId)) return false;
      const s = await peek(tabId);
      if (s && done(s)) return true;
    }
    return false;
  }
  async function runTask(task, opts = {}) {
    if (running) return;
    running = true;
    let tabId;
    try {
      const start = await eng(task.id, "start", { claim: !!opts.claim });
      if (start.stop) {
        if (opts.claim) notify(task.school, start.stop);
        return;
      }
      const prev = await getActive();
      tabId = opts.tabId ?? (prev?.taskId === task.id && await tabAlive(prev.tabId) ? prev.tabId : void 0);
      if (!tabId) tabId = (await chrome.tabs.create({ url: start.url, active: !!opts.focus })).id;
      else if (opts.focus) await focusTab(tabId);
      await setActive({ taskId: task.id, school: task.school, tabId, startedAt: Date.now(), phase: "working" });
      await tasks().catch(() => {
      });
      const page = chromePage(tabId);
      await page.waitForLoadState("domcontentloaded", { timeout: 45e3 }).catch(() => {
      });
      let state = start.state;
      for (let round = 0; round < 15; round++) {
        let outcome;
        let filled = 0;
        try {
          const r = await runEngine(page, deps(task.id, start, tabId), state, RUN_MS);
          state = r.state;
          outcome = r.outcome;
          filled = r.filled;
        } catch (e) {
          if (!await tabAlive(tabId)) outcome = { kind: "needs_you", reason: "stuck", note: "the portal tab was closed. Choose Run in my Chrome to carry on" };
          else outcome = { kind: "failed", note: `the agents hit a problem in Chrome: ${String(e?.message ?? e).slice(0, 160)}` };
        }
        const tab = await chrome.tabs.get(tabId).catch(() => null);
        const url = tab?.url;
        let host;
        try {
          host = url ? new URL(url).hostname : void 0;
        } catch {
          host = void 0;
        }
        const fin = await eng(task.id, "finish", { state, url, filled, host, outcome }).catch(() => ({}));
        if (fin.stop) {
          notify(task.school, "Paused in automaster. The tab stays open; nothing else happens until you resume.");
          break;
        }
        if (outcome.kind === "continue") continue;
        if (outcome.kind === "wait") {
          await setActive({ taskId: task.id, school: task.school, tabId, startedAt: Date.now(), phase: "waiting for an email" });
          await nap(Math.min(outcome.seconds, 120) * 1e3);
          continue;
        }
        if (outcome.kind === "submitted") {
          notify(`${task.school}: submitted`, "The application went in. automaster has recorded it.");
          break;
        }
        if (outcome.kind === "needs_you" && (outcome.reason === "captcha" || outcome.reason === "blocked")) {
          await setActive({ taskId: task.id, school: task.school, tabId, startedAt: Date.now(), phase: "waiting for you" });
          notify(`${task.school}: one check for you`, "Complete the check in the tab that just opened. The agents carry on by themselves.");
          await focusTab(tabId);
          if (await watch(tabId, 30, (s) => !s.captcha && !isBlockPage(s))) {
            await eng(task.id, "progress", { note: "carrying on after the check" }).catch(() => {
            });
            await nap(1500);
            continue;
          }
          break;
        }
        if (outcome.kind === "needs_you" && outcome.reason === "payment") {
          await setActive({ taskId: task.id, school: task.school, tabId, startedAt: Date.now(), phase: "waiting for payment" });
          notify(`${task.school}: ready to pay`, "Everything is filled in. Pay the application fee in the portal tab; the agents confirm the submission after.");
          await focusTab(tabId);
          const startUrl = url;
          if (await watch(tabId, 60, (s) => s.confirmation || !s.payment && s.url !== startUrl)) continue;
          break;
        }
        if (outcome.kind === "needs_you") notify(`${task.school}: needs you`, fin.note || outcome.note);
        break;
      }
    } catch (e) {
      notify(task.school, String(e?.message ?? e).slice(0, 200));
    } finally {
      running = false;
      await setActive(null);
      sheets.delete(task.id);
      await tasks().catch(() => {
      });
    }
  }
  async function poll() {
    const c = await cfg();
    if (!c.token || running) return;
    let data;
    try {
      data = await tasks();
    } catch {
      return;
    }
    if (data.paused || !c.auto) return;
    const now = Date.now();
    const next = data.tasks.find((t) => t.mode === "extension" && ["ready", "running"].includes(t.runner_status) && (!t.resume_at || t.resume_at <= now));
    if (next) runTask(next);
  }
  function ensureAlarm() {
    chrome.alarms.create("poll", { periodInMinutes: 1 });
  }
  chrome.runtime.onInstalled.addListener(ensureAlarm);
  chrome.runtime.onStartup.addListener(ensureAlarm);
  chrome.alarms.onAlarm.addListener((a) => a.name === "poll" && poll());
  async function handle(msg, sender) {
    if (msg.type === "bridge:hello") {
      const c = await cfg();
      const a = await getActive();
      return { version: VERSION, paired: !!c.token, running: a ? { id: a.taskId, school: a.school, phase: a.phase } : null };
    }
    if (msg.type === "bridge:pair") {
      const origin = new URL(sender.url).origin;
      if (!/^amr_[\w-]{20,}$/.test(msg.token)) throw new Error("bad key");
      await chrome.storage.local.set({ token: msg.token, api: origin, auto: true });
      ensureAlarm();
      setTimeout(poll, 500);
      return { paired: true, version: VERSION };
    }
    if (msg.type === "bridge:run" || msg.type === "popup:start") {
      const d = await tasks();
      const t = d.tasks.find((x) => x.id === msg.id);
      if (!t) throw new Error("that application isn't queued for submitting");
      if (running) {
        const a = await getActive();
        if (a?.taskId === t.id) return { started: true };
        throw new Error(`busy with ${a?.school ?? "another school"}; this one is next`);
      }
      runTask(t, { claim: true, focus: msg.type === "popup:start" || !!msg.focus });
      return { started: true };
    }
    if (msg.type === "bridge:kick" || msg.type === "popup:poll") {
      poll();
      return { ok: true };
    }
    if (msg.type === "popup:tasks") {
      const d = await tasks();
      return { ...d, active: await getActive() };
    }
    if (msg.type === "popup:attach") {
      const d = await tasks();
      const t = d.tasks.find((x) => x.id === msg.id);
      if (!t) throw new Error("not in your queue");
      if (running) throw new Error("busy with another school");
      runTask(t, { claim: true, tabId: msg.tabId });
      return { started: true };
    }
    return null;
  }
  chrome.runtime.onMessage.addListener((msg, sender, reply) => {
    handle(msg, sender).then(
      (v) => reply({ ok: true, value: v }),
      (e) => reply({ ok: false, error: String(e?.message ?? e) })
    );
    return true;
  });
})();
