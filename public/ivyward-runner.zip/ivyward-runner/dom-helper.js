(() => {
  if (window.__am) return;
  const textOf = (el) => (el ? (el.innerText || el.textContent || "").replace(/\s+/g, " ").trim() : "");
  // portals built from web components (salesforce experience sites, many modern forms) keep their fields inside
  // shadow roots, where document.querySelectorAll can't see. these look through every open shadow root too.
  // a salesforce application page nests thousands of components: the form sits far below the first few hundred
  // roots, so the walk goes deep (bounded by count and time) and is cached briefly, since one scan asks many times
  let rootCache = null, rootAt = 0;
  const roots = () => {
    const now = Date.now();
    if (rootCache && now - rootAt < 250) return rootCache;
    const out = [document];
    for (let i = 0; i < out.length && out.length < 20000 && Date.now() - now < 1500; i++) for (const el of out[i].querySelectorAll("*")) if (el.shadowRoot) out.push(el.shadowRoot);
    rootCache = out; rootAt = Date.now();
    return out;
  };
  // salesforce's lightning sites (and other lwc pages) fake shadow dom in javascript: they rewrite the page's own
  // querySelectorAll so components' insides are hidden from it, though the fields are ordinary elements on the page.
  // a tree walker reads the real document, so walk it (and every real shadow root) and match selectors ourselves
  let elCache = null, elAt = 0;
  const elements = () => {
    const now = Date.now();
    if (elCache && now - elAt < 250) return elCache;
    const out = [], seen = new Set(), queued = new Set();
    const queue = [document];
    for (let i = 0; i < queue.length && out.length < 150000 && Date.now() - now < 2500; i++) {
      let w;
      try { w = document.createTreeWalker(queue[i], 1); } catch (e) { continue; } // a faked shadow root isn't a real node
      for (let n = w.nextNode(); n; n = w.nextNode()) {
        if (!seen.has(n)) { seen.add(n); out.push(n); }
        const sr = n.shadowRoot;
        if (sr && !queued.has(sr)) { queued.add(sr); queue.push(sr); }
      }
    }
    // belt and braces: anything the ordinary search finds that the walk missed
    for (const r of roots()) for (const n of r.querySelectorAll("*")) if (!seen.has(n)) { seen.add(n); out.push(n); }
    elCache = out; elAt = Date.now();
    return out;
  };
  const matches = (el, sel) => { try { return el.matches(sel); } catch (e) { return false; } };
  const all = (sel) => elements().filter((el) => matches(el, sel));
  const one = (sel) => { for (const el of elements()) if (matches(el, sel)) return el; return null; };
  // the radio buttons that answer the same question as this one
  const radioGroup = (el) => {
    const q = 'input[type="radio"][name="' + CSS.escape(el.name) + '"]';
    let g = [];
    try { g = [...rootOf(el).querySelectorAll(q)]; } catch (e) {}
    return g.includes(el) ? g : all(q).filter((x) => x.form === el.form);
  };
  const rootOf = (el) => (el && el.getRootNode ? el.getRootNode() : document);
  const deepText = () => {
    const rs = roots();
    const parts = [document.body ? document.body.innerText : ""];
    let n = parts[0].length;
    for (const r of rs.slice(1)) { if (n > 40000) break; const t = r.textContent || ""; parts.push(t); n += t.length; }
    return parts.join(" ").replace(/\s+/g, " ");
  };
  const visible = (el) => {
    if (!el || el.disabled || el.readOnly || el.type === "hidden") return false;
    const s = getComputedStyle(el);
    if (s.visibility === "hidden" || s.display === "none") return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 || r.height > 0 || el.type === "radio" || el.type === "checkbox" || el.type === "file";
  };
  let seq = 0;
  const idOf = (el) => el.getAttribute("data-am-id") || (el.setAttribute("data-am-id", "f" + (++seq) + "_" + Math.random().toString(36).slice(2, 6)), el.getAttribute("data-am-id"));
  // validation messages sit next to fields ("Answer is required"): they're never the question
  const stripErr = (t) => (t || "").replace(/\b[\w ]{0,40}\b(is|are) (required|mandatory|missing|invalid)\b\.?/gi, " ").replace(/\bthis (field|question) is required\b\.?|\bplease (enter|select|choose|complete|provide)\b[^.]{0,40}\.?|\brequired field\b\.?|\binvalid (entry|value|format)\b\.?/gi, " ").replace(/\s+/g, " ").trim();
  const labelFor = (el) => {
    const parts = [];
    if (el.id) { const q = 'label[for="' + CSS.escape(el.id) + '"]'; const l = rootOf(el).querySelector(q) || one(q); if (l) parts.push(textOf(l)); }
    const wrap = el.closest("label"); if (wrap) parts.push(textOf(wrap));
    const by = el.getAttribute("aria-labelledby");
    if (by) parts.push(by.split(/\s+/).map((i) => textOf(rootOf(el).getElementById ? rootOf(el).getElementById(i) : document.getElementById(i))).join(" "));
    for (const a of ["aria-label", "placeholder", "title"]) if (el.getAttribute(a)) parts.push(el.getAttribute(a));
    let own = stripErr(parts.join(" ").replace(/\s+/g, " ").trim());
    // a bare "Month"/"Day"/"Year" or very short label means little alone: prefix the row's question.
    // not for radio/checkbox options ("Yes", "No"): those are answers, their question comes from groupLabel.
    // (only for labels that say nothing alone: "Email", "City" or "Phone" are complete questions)
    if ((!own || own.replace(/[^a-z]/gi, "").length <= 2 || /^(day|month|year|dd|mm|yy|yyyy|select|choose|please select|-+)\b/i.test(own.trim())) && el.type !== "radio" && el.type !== "checkbox") {
      let ctx = "";
      // 1. nearest ancestor with a little text of its own (minus this field's own option text)
      const mine = textOf(el);
      let a = el.parentElement;
      for (let i = 0; i < 4 && a && !ctx; i++, a = a.parentElement) {
        const t = stripErr((mine ? textOf(a).split(mine).join(" ") : textOf(a)).replace(/\s+/g, " ").trim());
        if (t && t.length <= 120) ctx = t;
        else if (t.length > 120) break;
      }
      // 2. the row's label element (slate's .form_label, a legend, a th)
      if (!ctx) {
        const row = el.closest(".form_question, .form-group, .field, .question, fieldset, tr, li") || (el.parentElement && el.parentElement.closest("div, p, span"));
        const q = row && row.querySelector(".form_label, legend, label:not([for]), th, .label, h3, h4");
        ctx = q ? stripErr(textOf(q)) : "";
      }
      if (ctx && !own.toLowerCase().includes(ctx.toLowerCase())) own = (ctx + " " + own).trim();
    }
    return own.slice(0, 300);
  };
  // the heading of the section a box sits in: its fieldset's legend, else the nearest heading above it on the page
  const HEADING = "h1, h2, h3, h4, h5, h6, legend, [role='heading'], .form_header, .form_question_header, .section-title, .section-header";
  const sectionOf = (el) => {
    const fs = el.closest("fieldset");
    const lg = fs && fs.querySelector("legend");
    if (lg && textOf(lg)) return textOf(lg);
    const doc = el.ownerDocument || document;
    if (!doc.body || !doc.body.contains(el)) return "";
    const w = doc.createTreeWalker(doc.body, NodeFilter.SHOW_ELEMENT);
    w.currentNode = el;
    for (let i = 0; i < 400 && w.previousNode(); i++) {
      const n = w.currentNode;
      if (n.matches && n.matches(HEADING)) { const t = textOf(n); if (t && t.length <= 120) return t; }
    }
    return "";
  };
  // a name, email or phone box in a section about someone else (a parent, a guardian, an emergency contact): the
  // section says whose. "First name" alone reads as the applicant's own, and mcgill's parents got the applicant's name
  const OTHER_PERSON = /\b(parents?|guardians?|mother|father|step-?(mother|father)|emergency|next of kin|spouse|partner|sponsor|sibling|brother|sister|family members?|contact person|m[eè]re|p[eè]re|tuteur|tutrice|conjoint)\b/i;
  const PERSONAL = /\b(name|nom|pr[eé]nom|e-?mail|courriel|phone|t[eé]l[eé]phone|mobile|occupation|profession|education|relationship|lien|birth|deceased|living|alive)\b/i;
  const inSection = (el, label) => {
    if (!label || !PERSONAL.test(label) || OTHER_PERSON.test(label)) return label;
    const sec = sectionOf(el);
    return sec && OTHER_PERSON.test(sec) ? (sec.slice(0, 80) + ": " + label).slice(0, 300) : label;
  };
  // a radio group's question: the nearest ancestor text once the option labels are taken out
  // (stirling puts several questions in one block; the first ancestor with its own short text is the question)
  const groupLabel = (radio) => {
    const group = radioGroup(radio);
    const opts = group.map((g) => labelFor(g) || g.value).filter(Boolean);
    const fs = radio.closest("fieldset");
    let p = radio.parentElement;
    for (let i = 0; i < 6 && p; i++, p = p.parentElement) {
      let t = textOf(p);
      const full = t;
      for (const o of opts) if (o) t = t.split(o).join(" ");
      t = stripErr(t.replace(/\s+/g, " ").trim());
      // "Part-time or Full-time *" minus its options leaves "or *": keep the whole line instead
      if (t && t.replace(/[^a-z]/gi, "").length < 5 && full.length <= 160) t = full;
      if (t && t.length <= 160) return t;
      if (t.length > 160) break;
    }
    if (fs && fs.querySelector("legend")) return textOf(fs.querySelector("legend"));
    return radio.name || "";
  };

  // a list is empty when nothing real is chosen: a blank value, or a placeholder shown ("Select…", "-- choose --").
  // not merely "the first option": manchester's "acting on behalf of applicants?" starts on No, its first option,
  // and looked unanswered for ever
  const PLACEHOLDER = /^\s*(-+\s*)?(select|choose|please (select|choose)|pick|none selected|--+)\b|^\s*$/i;
  const isEmpty = (el) => el.tagName === "SELECT" ? (el.selectedIndex < 0 || !el.value || PLACEHOLDER.test((el.options[el.selectedIndex] || {}).text || "")) : el.type === "checkbox" ? !el.checked : el.type === "file" ? !(el.files && el.files.length) : !String(el.value || "").trim();
  const typeOf = (el) => el.tagName === "SELECT" ? "select" : el.tagName === "TEXTAREA" ? "textarea" : (el.type || "text").toLowerCase();

  function fields(includeFilled) {
    const out = []; const seen = new Set();
    // the same label twice on a page (parent 1's and parent 2's "First name"): the later ones are numbered, counted
    // over filled and empty boxes alike so a box keeps its number whatever is filled
    const times = {};
    const nth = (label) => { if (!label) return label; const k = label.toLowerCase(); times[k] = (times[k] || 0) + 1; return times[k] > 1 ? label + " (" + times[k] + ")" : label; };
    for (const el of all("input, textarea, select")) {
      const type = typeOf(el);
      if (["hidden", "submit", "button", "reset", "image", "search"].includes(type) || !visible(el)) continue;
      // cookie banners and site search aren't part of the application: never touch them
      if (el.closest('#onetrust-consent-sdk, #onetrust-banner-sdk, [id*="cookie" i], [class*="cookie" i], [aria-label*="cookie" i], [id*="consent" i], [class*="consent" i], form[role="search"], [role="search"]')) continue;
      if (type === "radio") {
        if (!el.name || seen.has(el.name)) continue; seen.add(el.name);
        const group = radioGroup(el);
        const gl = nth(inSection(el, groupLabel(el)));
        if (!includeFilled && group.some((g) => g.checked)) continue;
        // "Will you be resident in the UK...? *": an asterisk anywhere in the question marks it required
        out.push({ id: idOf(el), label: gl, type: "radio", name: el.name, options: group.map((g) => labelFor(g) || g.value), required: group.some((g) => g.required || g.getAttribute("aria-required") === "true") || /\*/.test(gl) || !!el.closest('[aria-required="true"], .required, .mandatory') });
        continue;
      }
      const label = type === "checkbox" ? labelFor(el) : nth(inSection(el, labelFor(el)));
      if (!includeFilled && !isEmpty(el)) continue;
      const role = (el.getAttribute("role") || "").toLowerCase();
      const combo = type === "text" && (role === "combobox" || /^(list|both)$/i.test(el.getAttribute("aria-autocomplete") || "") || !!el.getAttribute("list") || !!el.closest('[class*="select2" i], [class*="react-select" i], [class*="combobox" i], [class*="autocomplete" i], [class*="typeahead" i]'));
      out.push({ id: idOf(el), label, type, combo: combo || undefined, name: el.name || undefined, autocomplete: el.autocomplete || undefined,
        options: type === "select" ? [...el.options].map((o) => o.text.trim()) : undefined,
        maxLength: el.maxLength > 0 && el.maxLength < 1000 ? el.maxLength : undefined,
        required: el.required || el.getAttribute("aria-required") === "true" || /\*\s*$|\*\s*\(/.test(label) || (type !== "checkbox" && /\*/.test(label) && label.length < 200) });
    }
    // dropdowns that are a button opening a list (salesforce lightning's comboboxes, many react selects): a list
    // field, with its options if the list is already on the page (lightning builds it on first opening)
    for (const el of all('button[role="combobox"], [role="combobox"]:not(input):not(select):not(textarea), input[role="combobox"][readonly], button[aria-haspopup="listbox"]')) {
      if (!visible(el) || el.closest('#onetrust-consent-sdk, [id*="cookie" i], [class*="cookie" i], [role="search"]')) continue;
      const shown = ((el.tagName === "INPUT" ? el.value : textOf(el)) || "").trim();
      const empty = !shown || /^(-+\s*)?(select|choose|please select|pick|none)\b/i.test(shown);
      if (!includeFilled && !empty) continue;
      const by = (el.getAttribute("aria-labelledby") || "").split(/\s+/).filter(Boolean).map((i) => one("#" + CSS.escape(i))).filter(Boolean).map(textOf).join(" ");
      const label = (labelFor(el) || el.getAttribute("aria-label") || by || "").replace(shown, "").trim() || by || shown;
      out.push({ id: idOf(el), label, type: "select", aria: true, name: el.getAttribute("name") || undefined, options: ariaOptions(el),
        required: el.getAttribute("aria-required") === "true" || /\*/.test(label) || !!el.closest('[aria-required="true"], .slds-is-required, .required') });
    }
    return out.slice(0, 150);
  }
  // the options of a button-dropdown's list, if the list is on the page
  function ariaOptions(el) {
    const ctl = el.getAttribute("aria-controls") || el.getAttribute("aria-owns");
    const list = ctl ? one("#" + CSS.escape(ctl)) : null;
    const opts = list ? [...list.querySelectorAll('[role="option"]')] : [];
    return opts.map((o) => (o.getAttribute("aria-label") || o.getAttribute("data-value") && textOf(o) || textOf(o)).trim()).filter(Boolean).slice(0, 400);
  }
  // after opening a button-dropdown: its options (the controlled list, or any list now showing)
  function openOptions(id) {
    const el = one('[data-am-id="' + id + '"]');
    const own = el ? ariaOptions(el) : [];
    if (own.length) return own;
    return [...all('[role="option"]')].filter(visible).map((o) => textOf(o).trim()).filter(Boolean).slice(0, 400);
  }
  // anything a person would click: real buttons and links, tabs, and the clickable divs some portals use
  // ("Create account" as a <div onclick> or a tab). a generic clickable that wraps a real button is skipped.
  const CLICKABLE = 'button, input[type="submit"], input[type="button"], a, [role="button"], [role="tab"], [role="link"], [role="menuitem"], summary';
  // a button with no text (an icon, or a peoplesoft button whose words are in its id): name it from the picture's alt
  // text, or from words in its id or name ("CIBAA_REG_WRK_SUBMIT_PB" -> "submit"), so the agents can press it
  const ACTION_WORDS = /(submit|register|create|sign_?up|save|next|continue|proceed|apply|login|log_?in|sign_?in)/i;
  function unnamed(b) {
    const img = b.querySelector && b.querySelector("img[alt], svg title, [aria-label]");
    const alt = img ? (img.getAttribute("alt") || img.getAttribute("aria-label") || img.textContent || "").trim() : "";
    if (alt) return alt;
    const key = (b.id || "") + " " + (b.getAttribute("name") || "") + " " + (typeof b.className === "string" ? b.className : "");
    const m = key.match(ACTION_WORDS);
    return m ? m[1].replace(/_/g, " ").toLowerCase().replace(/^(log|sign) ?(in|up)$/, "$1 $2") : "";
  }
  function buttons() {
    const real = [...all(CLICKABLE)];
    const generic = [...all('[onclick], [tabindex="0"]')].filter((e) => !e.matches(CLICKABLE) && !e.querySelector(CLICKABLE) && textOf(e).length <= 60 && !e.closest(CLICKABLE));
    return [...real, ...generic].filter(visible)
      .map((b) => ({ id: idOf(b), label: ((b.tagName === "INPUT" ? b.value : textOf(b)) || b.getAttribute("aria-label") || b.getAttribute("title") || unnamed(b)).trim().slice(0, 80), link: b.tagName === "A", href: b.tagName === "A" ? b.href : undefined, row: rowOf(b) }))
      .filter((b) => b.label);
  }
  // the short line a button sits on in a checklist ("Personal details   Incomplete   Edit"): how the portal marks
  // each section, which a section's button rarely says itself. only short rows; a whole page is no row
  function rowOf(b) {
    const r = b.closest('tr, li, [role="row"], [role="listitem"], .card, .panel, .list-group-item, .section-item, .checklist-item');
    if (!r) return undefined;
    const t = textOf(r).replace(/\s+/g, " ").trim();
    const marks = [...r.querySelectorAll('[class*="complete" i], [class*="status" i], [class*="check" i], [aria-label], img[alt], [title]')]
      .map((e) => ((typeof e.className === "string" ? e.className : "") + " " + (e.getAttribute("aria-label") || "") + " " + (e.getAttribute("alt") || "") + " " + (e.getAttribute("title") || "")).replace(/\s+/g, " ").trim())
      .filter((x) => /complete|incomplete|progress|started|done|required|check/i.test(x))
      .slice(0, 3)
      .join(" ");
    const out = (t + (marks ? " [" + marks + "]" : "")).slice(0, 220);
    return t.length <= 160 ? out : undefined;
  }
  // after typing into a search-as-you-type box, the list of matches: click the one that fits the value
  function pickOption(value) {
    const norm = (t) => t.toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, " ").trim();
    const want = norm(value);
    const opts = [...all('[role="option"], [role="listbox"] li, .select2-results__option, .ui-menu-item, [class*="option" i][id*="option" i], datalist option')].filter(visible);
    if (!opts.length) return null;
    const scored = opts.map((o) => ({ o, t: norm(textOf(o)) })).filter((x) => x.t && !/^(no (results|matches|options)|loading|searching)/.test(x.t));
    const hit = scored.find((x) => x.t === want) || scored.find((x) => x.t.startsWith(want)) || scored.find((x) => x.t.includes(want)) || (scored.length === 1 ? scored[0] : null);
    if (!hit) return null;
    hit.o.scrollIntoView({ block: "nearest" });
    hit.o.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
    hit.o.click();
    return textOf(hit.o).slice(0, 120);
  }
  // what sits at a point on screen, for checking a click chosen from a screenshot before making it
  function at(x, y) {
    const el = document.elementFromPoint(x, y);
    if (!el) return null;
    const c = el.closest(CLICKABLE) || el;
    return { tag: c.tagName.toLowerCase(), label: ((c.tagName === "INPUT" ? c.value : textOf(c)) || c.getAttribute("aria-label") || "").slice(0, 80), href: c.tagName === "A" ? c.href : null };
  }
  // a native dropdown at a point on screen (its open list never shows in a screenshot): choose the option that
  // matches the value, the way a person reading the list would ("English" -> "English / Anglais")
  function selectAt(x, y, value) {
    let el = document.elementFromPoint(x, y);
    while (el && el.shadowRoot) { const inner = el.shadowRoot.elementFromPoint(x, y); if (!inner || inner === el) break; el = inner; }
    const sel = el && (el.tagName === "SELECT" ? el : el.closest("label, div, td, li") && el.closest("label, div, td, li").querySelector("select"));
    if (!sel || sel.tagName !== "SELECT") return null;
    const norm = (t) => (t || "").toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, " ").trim();
    const v = norm(value);
    const opts = [...sel.options].filter((o) => norm(o.text) && !/^(select|choose|please|--)/.test(norm(o.text)));
    const hit = opts.find((o) => norm(o.text) === v || norm(o.value) === v) || opts.find((o) => norm(o.text).startsWith(v) || v.startsWith(norm(o.text))) || opts.find((o) => norm(o.text).split(" ").includes(v));
    if (!hit) return { options: opts.slice(0, 40).map((o) => o.text.trim()) };
    sel.value = hit.value;
    sel.dispatchEvent(new Event("input", { bubbles: true }));
    sel.dispatchEvent(new Event("change", { bubbles: true }));
    sel.dispatchEvent(new Event("blur", { bubbles: true }));
    return { chose: hit.text.trim() };
  }
  function setValue(el, v) {
    const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, "value").set.call(el, v);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.dispatchEvent(new Event("blur", { bubbles: true }));
  }
  function apply(f) {
    const el = one('[data-am-id="' + f.id + '"]');
    if (!el) return false;
    if (f.action === "fill") { if (el.maxLength > 0 && f.value.length > el.maxLength) return false; setValue(el, f.value); return true; }
    if (f.action === "choose") {
      // already showing that answer: leave it. re-choosing fires change, and peoplesoft reloads the page on every change
      if (el.tagName === "SELECT") { const o = [...el.options].find((x) => x.text.trim() === f.option); if (!o) return false; if (el.value === o.value && el.selectedIndex === o.index) return true; el.value = o.value; el.dispatchEvent(new Event("input", { bubbles: true })); el.dispatchEvent(new Event("change", { bubbles: true })); return true; }
      const hit = radioGroup(el).find((g) => (labelFor(g) || g.value) === f.option);
      if (!hit) return false; hit.click(); return true;
    }
    if (f.action === "check") { if (!el.checked) el.click(); return el.checked; }
    return false;
  }
  function snapshot() {
    const body = (roots().length > 1 ? deepText() : textOf(document.body)).slice(0, 20000);
    return {
      url: location.href,
      title: document.title,
      body: body.slice(0, 4000),
      captcha: !!one('iframe[src*="recaptcha"], iframe[src*="hcaptcha"], iframe[src*="turnstile"], iframe[src*="challenges.cloudflare"], .g-recaptcha, .h-captcha, .cf-turnstile, [data-sitekey]'),
      // "Hong Kong I.D. Card Number" on hkust's forgot-password page is not a payment card (nov 2026: it stopped a run
      // as "pay the fee" before the account existed)
      payment: !!one('input[autocomplete^="cc-"], iframe[src*="stripe"], iframe[src*="braintree"], iframe[src*="paypal"], iframe[src*="flywire"], iframe[src*="cybersource"], iframe[src*="authorize.net"]') || /\b(cardholder|card holder|cvv|cvc|credit card|debit card)\b/i.test(body) || /(?<!\b(?:i\.?\s?d\.?|identity|identification|student|national|hkid|id|insurance)\s)\bcard number\b/i.test(body),
      confirmation: /(application (has been |was )?(successfully )?submitted|thank you for (submitting|applying|your application)|submission (is )?complete|your application is complete|confirmation (number|code))/i.test(body),
      fingerprint: [...all("h1, h2, h3, legend, label")].slice(0, 40).map(textOf).join("|").slice(0, 2000),
      fields: fields(false),
      allFields: fields(true).map((f) => ({ id: f.id, label: f.label, type: f.type, name: f.name, autocomplete: f.autocomplete, required: f.required, aria: f.aria })),
      buttons: buttons(),
      // the browser's own checks (pattern, type, length): a box that breaks one stops the form posting and shows only
      // a tooltip, so the page "comes back" with nothing written on it. calgary's eID form works this way
      errors: [...nativeInvalid(), ...[...all('.error, .errors, [role="alert"], .invalid-feedback, .field-validation-error, .form_error, .validation-message, .has-error .help-block, .alert-danger, .errorMessage, .error-message, .message-container.error, .alert-error, .alert-warning, .notification.is-danger, .toast-error, .msg-error, .error-msg, .errortext, .error-text')]
        .filter(visible).map((e) => textOf(e)).filter((t) => t && t.length < 200)].slice(0, 5),
    };
  }
  function nativeInvalid() {
    const out = [];
    for (const el of all("input, select, textarea")) {
      if (out.length >= 3) break;
      if (!el.willValidate || !el.validity || el.validity.valid || el.validity.valueMissing) continue;
      if (el.type === "hidden" || el.type === "checkbox" || el.type === "radio" || !String(el.value || "").trim() || !visible(el)) continue;
      const why = el.title || el.validationMessage || "not accepted";
      const name = (labelFor(el) || el.name || "a box").split(why).join(" ").replace(/\s+/g, " ").trim().slice(0, 60);
      out.push((name + ": " + why).slice(0, 190));
    }
    return out;
  }
  // numbered marks on everything clickable or typeable in view, drawn over the page for a screenshot ("set of
  // marks"), so the model can point at element 12 instead of guessing pixels
  const MARKABLE = CLICKABLE + ', input:not([type="hidden"]), select, textarea, [role="option"], [role="combobox"], [role="checkbox"], [role="radio"], [role="switch"], [role="listbox"] li, [contenteditable="true"], label[for]';
  function marks(draw) {
    clearMarks();
    const vw = innerWidth, vh = innerHeight;
    const seen = new Set();
    const out = [];
    for (const el of all(MARKABLE + ', [onclick], [tabindex="0"]')) {
      if (out.length >= 90) break;
      const r = el.getBoundingClientRect();
      if (r.width < 4 || r.height < 4 || r.bottom < 0 || r.right < 0 || r.top > vh || r.left > vw) continue;
      const s = getComputedStyle(el);
      if (s.visibility === "hidden" || s.display === "none" || Number(s.opacity) === 0) continue;
      // skip an element covered by something else at its centre (a modal, a cookie bar), unless it's the cover itself
      const cx = Math.min(Math.max(r.left + r.width / 2, 1), vw - 1), cy = Math.min(Math.max(r.top + r.height / 2, 1), vh - 1);
      const top = document.elementFromPoint(cx, cy);
      if (top && top !== el && !el.contains(top) && !top.contains(el) && el.type !== "file" && el.type !== "checkbox" && el.type !== "radio") continue;
      const key = Math.round(r.left) + ":" + Math.round(r.top) + ":" + Math.round(r.width);
      if (seen.has(key)) continue;
      seen.add(key);
      const n = out.length + 1;
      el.setAttribute("data-am-mark", String(n));
      const tag = el.tagName.toLowerCase();
      const type = tag === "input" ? (el.type || "text") : tag === "select" ? "select" : tag === "textarea" ? "textarea" : (el.getAttribute("role") || tag);
      const label = (tag === "input" || tag === "select" || tag === "textarea") ? labelFor(el) || el.name || "" : ((tag === "input" ? el.value : textOf(el)) || el.getAttribute("aria-label") || el.getAttribute("title") || "");
      const value = tag === "select" ? (el.options[el.selectedIndex] ? el.options[el.selectedIndex].text : "") : tag === "input" || tag === "textarea" ? (el.type === "password" ? (el.value ? "••••" : "") : el.type === "checkbox" || el.type === "radio" ? (el.checked ? "checked" : "") : String(el.value || "").slice(0, 40)) : "";
      out.push({ n, type, label: label.replace(/\s+/g, " ").trim().slice(0, 70), value, x: Math.round(cx), y: Math.round(cy), w: Math.round(r.width), h: Math.round(r.height) });
    }
    if (draw) {
      const layer = document.createElement("div");
      layer.id = "__am_marks";
      layer.style.cssText = "position:fixed;inset:0;pointer-events:none;z-index:2147483647";
      for (const m of out) {
        const b = document.createElement("div");
        b.style.cssText = "position:fixed;border:2px solid #e11d48;border-radius:3px;left:" + (m.x - m.w / 2) + "px;top:" + (m.y - m.h / 2) + "px;width:" + m.w + "px;height:" + m.h + "px";
        const t = document.createElement("span");
        t.textContent = String(m.n);
        t.style.cssText = "position:absolute;left:-2px;top:-14px;background:#e11d48;color:#fff;font:600 10px/12px Arial,sans-serif;padding:0 3px;border-radius:2px";
        b.appendChild(t);
        layer.appendChild(b);
      }
      document.documentElement.appendChild(layer);
    }
    return out;
  }
  function clearMarks() {
    const l = document.getElementById("__am_marks");
    if (l) l.remove();
  }
  // a cheap fingerprint of what the screen shows, to tell whether a step changed anything
  function sig() {
    // the focused element, even inside a web component, and every field's value: typing into a box inside a shadow
    // root changes neither the page text nor the field count, but it does change this
    let a = document.activeElement;
    while (a && a.shadowRoot && a.shadowRoot.activeElement) a = a.shadowRoot.activeElement;
    const vals = all("input,select,textarea").map((e) => (e.type === "checkbox" || e.type === "radio" ? (e.checked ? "1" : "0") : (e.value || "").length)).join(",");
    let h = 0;
    for (let i = 0; i < vals.length; i++) h = (h * 31 + vals.charCodeAt(i)) | 0;
    return location.href + "|" + (document.body ? document.body.innerText.length : 0) + "|" + all("input,select,textarea").length + "|" + h + "|" + (a ? a.tagName + (a.getAttribute("data-am-mark") || "") : "") + "|" + scrollY;
  }
  const byId = (id) => one('[data-am-id="' + id + '"]');
  window.__am = { snapshot, apply, fields, pickOption, at, selectAt, marks, clearMarks, sig, byId, openOptions };
})();
